[MagicaVoxel : 8-bit Voxel Editor & Renderer]
================================
date    : 07/05/2016

version : 0.97.4

os      : Win32, MacOS 10.7+

website : https://ephtracy.github.io/

twitter : @ ephtracy