/* OptionsPanel */

#import <Cocoa/Cocoa.h>

extern NSString *OPDidChangeFirstResponderNotification;

@interface OptionsPanel : NSPanel
{
}
@end
