//
//  OptionsDocView.h
//  LDView
//
//  Created by Travis Cobbs on 6/15/08.
//  Copyright 2008 Travis Cobbs. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface OptionsDocView : NSView
{
}

- (BOOL)isFlipped;

@end
