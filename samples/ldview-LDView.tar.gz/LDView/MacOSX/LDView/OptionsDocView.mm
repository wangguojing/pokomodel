//
//  OptionsDocView.mm
//  LDView
//
//  Created by Travis Cobbs on 6/15/08.
//  Copyright 2008 Travis Cobbs. All rights reserved.
//

#import "OptionsDocView.h"


@implementation OptionsDocView

- (BOOL)isFlipped
{
	return YES;
}

@end
