/*
 *  MacSetup.h
 *  LDView
 *
 *  Created by Travis Cobbs on 6/11/12.
 *  Copyright 2012 __MyCompanyName__. All rights reserved.
 *
 */

#import <Cocoa/Cocoa.h>

#if MAC_OS_X_VERSION_MAX_ALLOWED <= 1040

typedef int32_t NSInteger;
typedef unsigned int32_t NSUInteger;
typedef float CGFloat;

#endif // Tiger

