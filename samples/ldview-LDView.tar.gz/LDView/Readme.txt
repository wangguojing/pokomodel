See Help.html for instructions on how to use the program.

See ChangeHistory.html for a list of changes made in each version that has
been released.

See license.txt for license information.
