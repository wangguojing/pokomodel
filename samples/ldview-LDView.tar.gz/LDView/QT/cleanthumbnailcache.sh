#!/bin/sh
rm -f ~/.cache/thumbnails/*/*.png
rm -f ~/.thumnails/*/*

