#! /bin/sh
`pwd`/LDView.app/Contents/MacOS/LDView $*
