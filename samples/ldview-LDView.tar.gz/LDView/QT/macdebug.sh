#! /bin/sh
gdb `pwd`/LDView.app/Contents/MacOS/LDView
