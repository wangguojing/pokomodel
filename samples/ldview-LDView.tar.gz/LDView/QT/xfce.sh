#!/bin/sh
cp xfce/ldraw.desktop /usr/srare/thumbnailers/

