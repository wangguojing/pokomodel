#include "CUIButton.h"

CUIButton::CUIButton(CUIWindow* parentWindow, int x, int y, int width, int height)
		  :CUIWindow(parentWindow, x, y, width, height)
{
}

/*
CUIButton::~CUIButton(void)
{
}
*/