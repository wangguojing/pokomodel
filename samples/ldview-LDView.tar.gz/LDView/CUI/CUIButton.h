#ifndef __CUIBUTTON_H__
#define __CUIBUTTON_H__

#include <CUI/CUIWindow.h>

class CUIButton: public CUIWindow
{
	public:
		CUIExport CUIButton(CUIWindow*, int, int, int, int);
	protected:
//		CUIExport ~CUIButton(void);
};

#endif
